﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GNSSDataProcessing
{
    public class DataModel
    {
        /// <summary>
        /// 单个卫星的观测数据类
        /// </summary>
        public class SatelliteObservation
        {
            public string SatelliteID { get; set; } //卫星标识符

            public DateTime Epoch { get; set; } //观测时间

            public double L1Phase { get; set; } //L1载波相位观测值

            public double L2Phase { get; set; } //L2载波相位观测值

            public double P1Pseudorange { get; set; } //L1伪距观测值

            public double P2Pseudorange { get; set; } //L2伪距观测值

            public double SNR1 { get; set; } //L1信号强度

            public double SNR2 { get; set; } //L2信号强度

            public bool HasCycleSlip { get; set; } //周跳标记

            public double CorrectedL1Phase { get; set; } //周跳修正后的L1相位

            public double CorrectedL2Phase { get; set; } //周跳修正后的L2相位

            public double SmoothedP1 { get; set; } //卡尔曼滤波平滑后的P1伪距

            public double SmoothedP2 { get; set; } //卡尔曼滤波平滑后的P2伪距

            /// <summary>
            /// 在类体的构造函数中进行实例化
            /// </summary>
            /// <param name="satelliteID"></param>
            /// <param name="epoch"></param>
            /// <param name="l1Phase"></param>
            /// <param name="l2Phase"></param>
            /// <param name="p1Pseudorange"></param>
            /// <param name="p2Pseudorange"></param>
            /// <param name="snr1"></param>
            /// <param name="snr2"></param>
            /// <param name="hasCycleSlip"></param>
            /// <param name="correctedL1Phase"></param>
            /// <param name="correctedL2Phase"></param>
            /// <param name="smoothedP1"></param>
            /// <param name="smoothedP2"></param>
            public SatelliteObservation(string satelliteID ,DateTime epoch,double l1Phase,double l2Phase,double p1Pseudorange,
                double p2Pseudorange,double snr1,double snr2,bool hasCycleSlip,double correctedL1Phase,double correctedL2Phase,double smoothedP1 = 0.0,double smoothedP2=0.0)
            {
                SatelliteID = satelliteID;
                Epoch = epoch;
                L1Phase = l1Phase;
                L2Phase = l2Phase;
                P1Pseudorange = p1Pseudorange;
                P2Pseudorange = p2Pseudorange;
                SNR1 = snr1;
                SNR2 = snr2;
                HasCycleSlip = hasCycleSlip;
                CorrectedL1Phase = correctedL1Phase;
                CorrectedL2Phase = correctedL2Phase;
                SmoothedP1 = smoothedP1;
                SmoothedP2 = smoothedP2;
            }

            //重写tostring方法
            public override string ToString()
            {
                string str1 = string.Format("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}\t{8}\t{9}\t{10}\t{11}\t{12}\t\n",
                    SatelliteID, Epoch, L1Phase, L2Phase, P1Pseudorange, P2Pseudorange,
                    SNR1, SNR2, HasCycleSlip, CorrectedL1Phase, CorrectedL2Phase,
                    SmoothedP1, SmoothedP2);

                return str1;
            }
        }


        /// <summary>
        /// 存放检测到的周跳信息类
        /// </summary>
        public class CycleSlip
        {
            public string SatelliteID { get; set; } //卫星标识符

            public DateTime Epoch { get; set; } //周跳发生的时间

            public double L1SlipSize { get; set; } //L1载波周跳大小

            public double L2SlipSize { get; set; } //L2载波周跳大小

            public CycleSlip(string satelliteID, DateTime epoch, double l1SlipSize, double l2SlipSize)
            {
                SatelliteID = satelliteID;
                Epoch = epoch;
                L1SlipSize = l1SlipSize;
                L2SlipSize = l2SlipSize;
            }

            public override string ToString()
            {
                string str1 = string.Format("{0}\t{1}\t{2}\t{3}\t\n", SatelliteID, Epoch, L1SlipSize, L2SlipSize);
                return str1;
            }

        }

    }
}
