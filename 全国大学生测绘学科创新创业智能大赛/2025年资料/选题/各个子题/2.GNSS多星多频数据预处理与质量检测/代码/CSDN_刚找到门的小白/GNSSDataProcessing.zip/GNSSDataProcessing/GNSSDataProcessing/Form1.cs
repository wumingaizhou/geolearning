﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace GNSSDataProcessing
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //所需参数声明
        public List<DataModel.SatelliteObservation> observations; //存放原始数据
        public List<DataModel.CycleSlip> cycleSlips; //存放周跳检测结果
        public List<DataModel.SatelliteObservation> correctCycleSlipsResult; //存放纠正周跳误差后的数据
        public Dictionary<string, double> multipathEstimates;//存放多路径效应检测结果
        public List<DataModel.SatelliteObservation> multipathCorrectedResult;//存放修正多路径效应后的数据
        public List<DataModel.SatelliteObservation> smoothResults;//存放伪距平滑结果
        public string data1, data2, data3;

        //方法声明
        rawDataReader dataReader = new rawDataReader();
        Algorithms algorithms = new Algorithms();
        ResultSaver resultSaver = new ResultSaver();
        ShowResults showResults = new ShowResults();


        /// <summary>
        /// 读取原始数据按钮
        /// </summary>
        private void btnReadRawData_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "OBS数据|*.obs";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                if(filePath != null)
                {
                    observations = dataReader.ReadObservations(filePath);

                    string str = "";
                    for(int i = 0; i < observations.Count; i++)
                    {
                        str += observations[i].ToString();
                    }
                    rtbShowRawData.Text = str;
                }
                else
                {
                    throw new Exception("请先选择数据文件！");
                }
            }
        }

        /// <summary>
        /// 周跳检测按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCycleSlipDetector_Click(object sender, EventArgs e)
        {
            try
            {
                cycleSlips = algorithms.DetectCycleSlips(observations);

                correctCycleSlipsResult = algorithms.CorrectCycleSlips(observations, cycleSlips);

                MessageBox.Show("周跳检测完毕！");

            }
            catch
            {
                throw new Exception("周跳检测出错！");
            }

        }

        /// <summary>
        /// 多路径效应检测按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnMultipathEstimator_Click(object sender, EventArgs e)
        {
            try
            {
                multipathEstimates = algorithms.EstimateMultiPath(correctCycleSlipsResult);

                multipathCorrectedResult = algorithms.ApplyMultipathCorrection(correctCycleSlipsResult, multipathEstimates);

                MessageBox.Show("多路径效应检测完毕！");
            }
            catch
            {
                throw new Exception("多路径效应检测过程出错！");
            }
        }

        /// <summary>
        /// 伪距平滑处理按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPseudorangeSmoother_Click(object sender, EventArgs e)
        {
            try
            {
                smoothResults = algorithms.SmoothPseudorange(multipathCorrectedResult);

                MessageBox.Show("伪距平滑处理完毕！");
            }
            catch
            {
                throw new Exception("伪距平滑处理过程出错！");
            }
        }

        /// <summary>
        /// 保存结果到文件按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSaver_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Filter = "文本文件|*.txt";
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName;
                    resultSaver.Saver(filePath, cycleSlips, multipathEstimates, smoothResults);

                }
                MessageBox.Show("成功保存结果到文本文件");
            }
            catch
            {
                throw new Exception("保存结果到文件过程出错！");
            }

        }

        /// <summary>
        /// 结果展示按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnShowResults_Click(object sender, EventArgs e)
        {
            try
            {
                (data1, data2, data3) = showResults.Show(cycleSlips, multipathEstimates, smoothResults);

                rtbShowCycleSlipData.Text = data1;
                rtbShowMultipathEstimator.Text = data2;
                rtbShowSmootherData.Text = data3;
            }
            catch
            {
                throw new Exception("展示结果过程出错！");
            }
        }
    }
}
