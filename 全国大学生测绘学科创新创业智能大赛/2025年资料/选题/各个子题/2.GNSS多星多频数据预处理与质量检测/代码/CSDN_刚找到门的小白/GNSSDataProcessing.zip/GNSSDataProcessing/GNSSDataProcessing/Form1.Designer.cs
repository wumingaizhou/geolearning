﻿
namespace GNSSDataProcessing
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.rtbShowCycleSlipData = new System.Windows.Forms.RichTextBox();
            this.rtbShowMultipathEstimator = new System.Windows.Forms.RichTextBox();
            this.rtbShowSmootherData = new System.Windows.Forms.RichTextBox();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.btnReadRawData = new System.Windows.Forms.Button();
            this.btnCycleSlipDetector = new System.Windows.Forms.Button();
            this.btnMultipathEstimator = new System.Windows.Forms.Button();
            this.btnPseudorangeSmoother = new System.Windows.Forms.Button();
            this.btnSaver = new System.Windows.Forms.Button();
            this.btnShowResults = new System.Windows.Forms.Button();
            this.rtbShowRawData = new System.Windows.Forms.RichTextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1908, 1247);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.splitContainer1);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1900, 1215);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "程序执行";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.rtbShowSmootherData);
            this.tabPage2.Controls.Add(this.rtbShowMultipathEstimator);
            this.tabPage2.Controls.Add(this.rtbShowCycleSlipData);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1900, 1215);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "结果展示";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // rtbShowCycleSlipData
            // 
            this.rtbShowCycleSlipData.Location = new System.Drawing.Point(-4, 0);
            this.rtbShowCycleSlipData.Name = "rtbShowCycleSlipData";
            this.rtbShowCycleSlipData.Size = new System.Drawing.Size(583, 1219);
            this.rtbShowCycleSlipData.TabIndex = 0;
            this.rtbShowCycleSlipData.Text = "";
            // 
            // rtbShowMultipathEstimator
            // 
            this.rtbShowMultipathEstimator.Location = new System.Drawing.Point(576, 0);
            this.rtbShowMultipathEstimator.Name = "rtbShowMultipathEstimator";
            this.rtbShowMultipathEstimator.Size = new System.Drawing.Size(676, 1230);
            this.rtbShowMultipathEstimator.TabIndex = 0;
            this.rtbShowMultipathEstimator.Text = "";
            // 
            // rtbShowSmootherData
            // 
            this.rtbShowSmootherData.Location = new System.Drawing.Point(1247, 0);
            this.rtbShowSmootherData.Name = "rtbShowSmootherData";
            this.rtbShowSmootherData.Size = new System.Drawing.Size(653, 1212);
            this.rtbShowSmootherData.TabIndex = 0;
            this.rtbShowSmootherData.Text = "";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.btnShowResults);
            this.splitContainer1.Panel1.Controls.Add(this.btnSaver);
            this.splitContainer1.Panel1.Controls.Add(this.btnPseudorangeSmoother);
            this.splitContainer1.Panel1.Controls.Add(this.btnMultipathEstimator);
            this.splitContainer1.Panel1.Controls.Add(this.btnCycleSlipDetector);
            this.splitContainer1.Panel1.Controls.Add(this.btnReadRawData);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.rtbShowRawData);
            this.splitContainer1.Size = new System.Drawing.Size(1894, 1209);
            this.splitContainer1.SplitterDistance = 285;
            this.splitContainer1.TabIndex = 0;
            // 
            // btnReadRawData
            // 
            this.btnReadRawData.Location = new System.Drawing.Point(29, 51);
            this.btnReadRawData.Name = "btnReadRawData";
            this.btnReadRawData.Size = new System.Drawing.Size(165, 77);
            this.btnReadRawData.TabIndex = 0;
            this.btnReadRawData.Text = "原始数据读取";
            this.btnReadRawData.UseVisualStyleBackColor = true;
            this.btnReadRawData.Click += new System.EventHandler(this.btnReadRawData_Click);
            // 
            // btnCycleSlipDetector
            // 
            this.btnCycleSlipDetector.Location = new System.Drawing.Point(29, 253);
            this.btnCycleSlipDetector.Name = "btnCycleSlipDetector";
            this.btnCycleSlipDetector.Size = new System.Drawing.Size(165, 72);
            this.btnCycleSlipDetector.TabIndex = 0;
            this.btnCycleSlipDetector.Text = "周跳检测与修复";
            this.btnCycleSlipDetector.UseVisualStyleBackColor = true;
            this.btnCycleSlipDetector.Click += new System.EventHandler(this.btnCycleSlipDetector_Click);
            // 
            // btnMultipathEstimator
            // 
            this.btnMultipathEstimator.Location = new System.Drawing.Point(29, 437);
            this.btnMultipathEstimator.Name = "btnMultipathEstimator";
            this.btnMultipathEstimator.Size = new System.Drawing.Size(165, 73);
            this.btnMultipathEstimator.TabIndex = 0;
            this.btnMultipathEstimator.Text = "多路径检测与修复";
            this.btnMultipathEstimator.UseVisualStyleBackColor = true;
            this.btnMultipathEstimator.Click += new System.EventHandler(this.btnMultipathEstimator_Click);
            // 
            // btnPseudorangeSmoother
            // 
            this.btnPseudorangeSmoother.Location = new System.Drawing.Point(29, 656);
            this.btnPseudorangeSmoother.Name = "btnPseudorangeSmoother";
            this.btnPseudorangeSmoother.Size = new System.Drawing.Size(165, 57);
            this.btnPseudorangeSmoother.TabIndex = 0;
            this.btnPseudorangeSmoother.Text = "相位平滑伪距";
            this.btnPseudorangeSmoother.UseVisualStyleBackColor = true;
            this.btnPseudorangeSmoother.Click += new System.EventHandler(this.btnPseudorangeSmoother_Click);
            // 
            // btnSaver
            // 
            this.btnSaver.Location = new System.Drawing.Point(29, 833);
            this.btnSaver.Name = "btnSaver";
            this.btnSaver.Size = new System.Drawing.Size(165, 65);
            this.btnSaver.TabIndex = 0;
            this.btnSaver.Text = "保存结果";
            this.btnSaver.UseVisualStyleBackColor = true;
            this.btnSaver.Click += new System.EventHandler(this.btnSaver_Click);
            // 
            // btnShowResults
            // 
            this.btnShowResults.Location = new System.Drawing.Point(29, 1019);
            this.btnShowResults.Name = "btnShowResults";
            this.btnShowResults.Size = new System.Drawing.Size(165, 61);
            this.btnShowResults.TabIndex = 0;
            this.btnShowResults.Text = "查看处理结果";
            this.btnShowResults.UseVisualStyleBackColor = true;
            this.btnShowResults.Click += new System.EventHandler(this.btnShowResults_Click);
            // 
            // rtbShowRawData
            // 
            this.rtbShowRawData.Location = new System.Drawing.Point(10, 3);
            this.rtbShowRawData.Name = "rtbShowRawData";
            this.rtbShowRawData.Size = new System.Drawing.Size(1602, 1201);
            this.rtbShowRawData.TabIndex = 0;
            this.rtbShowRawData.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1908, 1247);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.RichTextBox rtbShowSmootherData;
        private System.Windows.Forms.RichTextBox rtbShowMultipathEstimator;
        private System.Windows.Forms.RichTextBox rtbShowCycleSlipData;
        private System.Windows.Forms.Button btnShowResults;
        private System.Windows.Forms.Button btnSaver;
        private System.Windows.Forms.Button btnPseudorangeSmoother;
        private System.Windows.Forms.Button btnMultipathEstimator;
        private System.Windows.Forms.Button btnCycleSlipDetector;
        private System.Windows.Forms.Button btnReadRawData;
        private System.Windows.Forms.RichTextBox rtbShowRawData;
    }
}

