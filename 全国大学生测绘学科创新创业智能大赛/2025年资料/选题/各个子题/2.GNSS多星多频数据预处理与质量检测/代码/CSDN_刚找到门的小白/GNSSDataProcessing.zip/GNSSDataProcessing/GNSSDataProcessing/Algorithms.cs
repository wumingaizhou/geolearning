﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GNSSDataProcessing
{
    /// <summary>
    /// 核心算法处理
    /// </summary>
    public class Algorithms
    {

        //----------------------------------周跳处理区----------------------------------//

        //周跳检测阈值（单位：周）
        private const double Threshold = 0.3;


        /// <summary>
        /// 检测周跳
        /// </summary>
        public List<DataModel.CycleSlip> DetectCycleSlips(List<DataModel.SatelliteObservation> observations)
        {
            var cycleSlips = new List<DataModel.CycleSlip> (); //用于存放监测到的周跳列表
            var satGroups = observations.GroupBy(o => o.SatelliteID);//根据卫星编号 SatelliteID 对观测数据进行分组


            //按卫星分组处理观测数据
            foreach (var satGroup in satGroups)
            {
                //对名为 satGroup 的集合中的元素，
                //按照元素的 Epoch（观测时刻）属性值进行升序排序，
                //然后将排序后的结果转换为列表并赋值给变量 sortedObs
                var sortedObs = satGroup.OrderBy(o => o.Epoch).ToList();

                double? previousMW = null;//声明了一个可空的双精度浮点型变量 previousMW，并将其初始化为 null 

                for (int i = 0; i < sortedObs.Count; i++)
                {
                    var obs = sortedObs[i];
                    double mw = CalculateMelbourneWubbena(obs);//对每一个检测值，计算MW

                    if (previousMW.HasValue) //判断previousMW是否有值
                    {
                        double diff = Math.Abs(mw - previousMW.Value); //计算当前历元 mw 与前一历元的MW值之间差值的绝对值。

                        if (diff > Threshold)//大于阈值，就判定发生了周跳
                        {
                            //向 cycleSlips 列表中添加一个新的周跳记录
                            cycleSlips.Add(new DataModel.CycleSlip(obs.SatelliteID, obs.Epoch, diff,diff));
                               
                            //标记当前观测数据 obs 发生了周跳。
                            obs.HasCycleSlip = true;
                        }
                    }

                    previousMW = mw;//进行迭代更新，以进行下一轮判断
                }
            }

            return cycleSlips; //返回周跳列表
        }

        /// <summary>
        /// 该方法根据输入的卫星观测数据obs，
        /// 按照 Melbourne - Wubbena 组合公式计算并返回相应的组合值。
        /// 通过监测 MW 组合值的变化，可以及时探测到周跳的发生
        /// </summary>
        /// <param name="obs">卫星观测数据</param>
        /// <returns>MW组合值</returns>
        private double CalculateMelbourneWubbena(DataModel.SatelliteObservation obs)
        {

            const double lambda1 = 0.19029367; //L1波长
            const double lambda2 = 0.24421021; //L2波长

            double phaseDiff = obs.L1Phase - obs.L2Phase; //相位差
            double pseudorangeDiff = obs.P1Pseudorange - obs.P2Pseudorange; //伪距差
            double wavelengthDiff = lambda1 - lambda2; //波长差

            //按照 Melbourne - Wubbena 组合公式(L1 - L2) - (P1 - P2)/(λ1 - λ2)进行计算，返回计算结果。
            return phaseDiff - (pseudorangeDiff / wavelengthDiff);
        }


        /// <summary>
        /// 修复观测数据中的周跳
        /// </summary>
        /// <param name="observations">卫星观测数据列表</param>
        /// <param name="slips">监测到的周跳列表</param>
        public List<DataModel.SatelliteObservation> CorrectCycleSlips(List<DataModel.SatelliteObservation> observations, List<DataModel.CycleSlip> slips)
        {
            var correctCycleSlipsResult = new List<DataModel.SatelliteObservation>();

            foreach (var slip in slips)
            {
                //利用lambda表达式：(参数列表) => 表达式或语句块
                //从observations列表中找到与slip对应的发生周跳的观测数据点
                //FirstOrDefault方法用于在observations集合中查找满足指定条件的第一个元素，如果没有找到，则返回默认值
                var obs = observations.FirstOrDefault(o => o.SatelliteID == slip.SatelliteID && o.Epoch == slip.Epoch);


                //当确实有周跳存在时，就利用线性内插方法进行简单的修复。
                if (obs != null)
                {
                    int index = observations.IndexOf(obs); //确定存在周跳的数据的位置
                    if (index > 0 && index < observations.Count - 1) //确保这个数据不是第一个也不是最后一个，这样才能进行线性内插
                    {
                        var prevObs = observations[index - 1];//获取这个数据的前一个观测值数据
                        var nextObs = observations[index + 1];//获取后一个

                        //通过简单求平均的方法，来对CorrectedL1Phase和CorrestedL2Phase重新赋值，即修复L1和L2的相位周跳
                        obs.CorrectedL1Phase = (prevObs.L1Phase + nextObs.L1Phase) / 2;
                        obs.CorrectedL2Phase = (prevObs.L2Phase + nextObs.L2Phase) / 2;
                    }
                }
            }

            foreach(var obs in observations)
            {
                correctCycleSlipsResult.Add(obs);
            }

            return correctCycleSlipsResult;
        }

        //--------------------------------------多路径处理区-----------------------------------------//

        /// <summary>
        /// 估计观测数据中的多路径效应
        /// </summary>
        /// <param name="observations">周跳处理后的观测数据</param>
        /// <returns>返回多路径效应字典数据（ID，多路径效应产生的误差值）</returns>
        public Dictionary<string, double> EstimateMultiPath(List<DataModel.SatelliteObservation> observations)
        {
            var multipathEstimates = new Dictionary<string, double>(); //存放多路径估计结果
            var satGroups = observations.GroupBy(o => o.SatelliteID); //将卫星数据按照ID分组


            //对每一组数据进行多路径误差计算
            foreach (var satgroup in satGroups)
            {
                double averageMP = satgroup.Average(o => CalculateMultipath(o));
                multipathEstimates[satgroup.Key] = averageMP; //每一颗卫星的多路径误差都是这一组观测数据的平均值，使其更具有普遍性
            }

            return multipathEstimates;
        }


        /// <summary>
        /// 计算单个观测数据的多路径值
        /// </summary>
        /// <param name="obs">卫星观测数据</param>
        /// <returns>多路径值（米）</returns>
        private double CalculateMultipath(DataModel.SatelliteObservation obs)
        {
            const double lambda1 = 0.19029367;//L1波长（米）
            return obs.P1Pseudorange - (obs.L1Phase * lambda1);//多路径计算公式：MP = P1 - L1*λ1

            //在这里由于假设了L2的多路径值为L1的80%，故此处只计算了L1的多路径值，实际情况下，还要按照要求根据公式来进行计算。
            //当然啦，我们计算得到的多路径值也可能为0，这就表明该卫星不存在多路径误差，在下面的方法中进行改正的时候，
            //P1Pseudorange和P2Pseudorange也就都是减去0，不会受到影响。
        }

        /// <summary>
        /// 对观测数据中的伪距观测值进行多路径误差修正。
        /// </summary>
        /// <param name="observations">卫星观测数据列表</param>
        /// <param name="estimates">多路径效应估计结果</param>
        public List<DataModel.SatelliteObservation> ApplyMultipathCorrection(List<DataModel.SatelliteObservation> observations, Dictionary<string, double> estimates)
        {
            var multipathCorrectedResult = new List<DataModel.SatelliteObservation>();

            foreach (var obs in observations)
            {
                //从 estimates 字典中获取与当前观测数据 obs 的卫星 ID（obs.SatelliteID）对应的多路径误差值 mpValue
                //TryGetValue（指定键，返回该键对应值的存放变量）
                //即是说，在estimates字典中找对应ID，找得到就把这个ID对应的值赋给mpValue并返回
                if (estimates.TryGetValue(obs.SatelliteID, out double mpValue)) //满足则执行伪距观测值修正
                {
                    //如果这一条则执行伪距观测值修正
                    obs.P1Pseudorange -= mpValue;
                    obs.P2Pseudorange -= mpValue * 0.8;
                }

                multipathCorrectedResult.Add(obs);
            }

            return multipathCorrectedResult;
        }


        //-----------------------------------伪距平滑处理区--------------------------------//

        /// <summary>
        /// 卡尔曼滤波器实现，用于伪距平滑处理
        /// </summary>
        public class KalmanFilter
        {
            private double _state; //状态估计值
            private double _covariance; //状态协方差，用于衡量状态估计值的不确定性
            private readonly double _processNoise; //过程噪声，描述系统本身的不确定性
            private readonly double _measurementNoise; //测量噪声，体现测量数据的误差
            private bool _initialized; //初始化标志


            /// <summary>
            /// 初始化卡尔曼滤波器
            /// </summary>
            /// <param name="processNoise">过程噪声系数</param>
            /// <param name="measurementNoise">测量噪声系数</param>
            public KalmanFilter(double processNoise = 0.01, double measurementNoise = 1.0)
            {
                _processNoise = processNoise;
                _measurementNoise = measurementNoise;
                _state = 0;
                _covariance = 100;
                _initialized = false;
            }


            /// <summary>
            /// 处理单个观测值，进行状态估计和伪距平滑
            /// </summary>
            /// <param name="obs">卫星观测数据</param>
            public void Process(DataModel.SatelliteObservation obs)
            {
                //假设卫星到接收机的距离变化是平滑的。
                const double lambda1 = 0.19029367;//L1波长

                double z = obs.P1Pseudorange; //测量值（伪距，即粗糙的卫星与接收机之间的距离）
                double h = obs.CorrectedL1Phase * lambda1;//预测值通过将观测数据obs中的已修正 L1 相位乘以 L1 波长lambda1，得到预测值h，此值相当于从相位信息预测出的距离。

                if (!_initialized)//判断是否是首次运行
                {
                    //初始化状态
                    _state = z; //将当前测量的伪距作为初始状态
                    _covariance = 1.0; //初始化协方差为1.0，用于衡量状态估计的不确定性
                    _initialized = true; //将初始化标志设置为true，表示已完成初始化
                    obs.SmoothedP1 = z; //将当前伪距值作为平滑后的 P1 伪距赋值给观测数据obs中的SmoothedP1字段

                    return;//完成首次初始化后直接返回，不进行后续的预测和更新步骤。
                }

                //当不是首次运行时，执行以下步骤

                //------------------------------------------预测步骤：

                double x_pred = _state; //将上一时刻的状态_state作为当前时刻的状态预测值x_pred
                double P_pred = _covariance + _processNoise; //计算预测协方差P_pred，它是上一时刻的协方差_covariance加上过程噪声_processNoise


                //-------------------------------------------更新步骤：

                double K = P_pred / (P_pred + _measurementNoise); //计算卡尔曼增益K，它是预测协方差P_pred与（预测协方差P_pred加上测量噪声_measurementNoise）的比值
                                                                  //卡尔曼增益 K 的计算公式本质上是一个加权因子，
                                                                  //它决定了在融合预测值和测量值时，测量值所占的权重。
                                                                  //具体来说，当测量噪声较小时，分母 P_pred + _measurementNoise 相对较小，
                                                                  //卡尔曼增益 K 会较大，意味着更相信测量值；反之，当测量噪声较大时，K 会较小，更依赖预测值


                _state = x_pred + K * (z - h); //根据卡尔曼增益K、测量值z与预测值h的差值，对状态进行更新。


                //这一步的作用是根据卡尔曼增益调整状态估计的不确定性。
                //当卡尔曼增益较大（即更相信测量值）时，(1 - K) 会较小，
                //更新后的协方差会减小，意味着状态估计的不确定性降低；
                //反之，当卡尔曼增益较小时，更新后的协方差会相对较大，状态估计的不确定性增加。
                _covariance = (1 - K) * P_pred; //根据卡尔曼增益K和预测协方差P_pred，更新协方差。


                //--------------------------------------------保存结果

                //保存平滑后伪距值
                obs.SmoothedP1 = _state;
                obs.SmoothedP2 = _state * (obs.P2Pseudorange / obs.P1Pseudorange);//对P2按比例进行更新
            }

        }

        /// <summary>
        /// 对观测数据中的伪距进行平滑处理
        /// </summary>
        /// <param name="observations">卫星观测数据列表</param>
        public List<DataModel.SatelliteObservation> SmoothPseudorange(List<DataModel.SatelliteObservation> observations)
        {
            var smoothResults = new List<DataModel.SatelliteObservation>();

            var satGroups = observations.GroupBy(o => o.SatelliteID);

            //为每颗卫星创建独立的卡尔曼滤波器进行平滑处理
            foreach (var satGroup in satGroups)
            {
                var sortedObs = satGroup.OrderBy(o => o.Epoch).ToList();
                var KalmanFilter = new KalmanFilter();

                foreach (var obs in sortedObs)
                {
                    KalmanFilter.Process(obs);
                    smoothResults.Add(obs);
                }
            }

            return smoothResults;
        }
    }
}
