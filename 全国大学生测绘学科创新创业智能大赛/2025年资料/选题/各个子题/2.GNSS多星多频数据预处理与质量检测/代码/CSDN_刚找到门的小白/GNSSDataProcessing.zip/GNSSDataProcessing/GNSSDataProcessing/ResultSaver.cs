﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace GNSSDataProcessing
{
    //保存所有处理结果
    public class ResultSaver
    {
        public void Saver(string filePath, List<DataModel.CycleSlip> cycleSlips, Dictionary<string, double> multipathEstimates, List<DataModel.SatelliteObservation> smoothResults)
        {
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                //保存周跳检测结果
                writer.WriteLine("周跳检测结果：\n");
                for(int i = 0; i < cycleSlips.Count; i++)
                {
                    writer.WriteLine(cycleSlips[i].ToString());
                }

                writer.WriteLine("\n");

                //保存多路径效应检测结果
               foreach(var kvp in multipathEstimates)
                {
                    writer.WriteLine($"卫星ID：{kvp.Key}\t多路径效应误差{kvp.Value}");
                }

                writer.WriteLine("\n");

                //保存伪距平滑结果
                for(int i = 0; i < smoothResults.Count; i++)
                {
                    writer.WriteLine(smoothResults[i].ToString());
                }

            }

        }

    }
}
