﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace GNSSDataProcessing
{
    /// <summary>
    /// 读取并解析原始数据类
    /// </summary>
    public class rawDataReader
    {
        /// <summary>
        /// 从RINEX格式文件读取卫星观测数据
        /// </summary>
        /// <param name="filePath">RINEX文件路径</param>
        /// <returns>卫星观测数据列表</returns>
        public List<DataModel.SatelliteObservation> ReadObservations(string filePath)
        {
            var observations = new List<DataModel.SatelliteObservation>(); //存储卫星观测数据
            string[] lines = File.ReadAllLines(filePath); //从文件读取所有行，每一行作为lines的一个元素

            int currentLine = 0; //记录当前处理的是文件第几行
            bool inHeader = true; //用于标记是够处于文件头部分
            string currentSatellite = ""; //用于记录当前处理的卫星编号

            //跳过文件头部分，找到数据所在部分
            while (inHeader && currentLine < lines.Length)
            {
                if (lines[currentLine].Contains("END OF HEADER"))
                    inHeader = false;
                currentLine++;
            }

            //解析数据部分
            while (currentLine < lines.Length)
            {
                string line = lines[currentLine].Trim(); //清除当前所处行中数据的开头和结尾所存在的空白字符

                //这行代码使用正则表达式来判断字符串 line 是否以 G、C 或 E 开头,并且紧接着是两位数字。Regex 是.NET 框架中用于处理正则表达式的类，
                //IsMatch 方法用于判断输入字符串是否与指定的正则表达式模式匹配。
                //^ 表示字符串的开始位置，[GCE] 表示匹配 G、C、E 中的任意一个字符，[0-9]{2} 表示匹配两位数字。
                if (Regex.IsMatch(line, @"^[GCE][0-9]{2}"))
                {
                    currentSatellite = line.Substring(0, 3);
                    currentLine++;
                    continue;
                }

                //解析观测数据行，包含时间和观测值
                if (line.Length > 20 && Regex.IsMatch(line.Substring(0, 4), @"^[0-9]{4}"))
                {
                    try
                    {
                        var obs = ParseObservationLine(line, currentSatellite); //obs中存储的即解析后的数据
                        if (obs != null)
                        {
                            observations.Add(obs);
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error parsing line {currentLine}:{ex.Message}");
                    }
                }

                currentLine++;
            }
            return observations;

        }


        /// <summary>
        /// 解析RINEX格式的观测数据行
        /// </summary>
        /// <param name="line">数据行文本</param>
        /// <param name="satelliteId">卫星ID</param>
        /// <returns>解析后的卫星观测数据</returns>
        private DataModel.SatelliteObservation ParseObservationLine(string line, string satelliteID)
        {
            //解析时间部分（格式：YYYY MM DD HH MM SS.SSS）
            int year = int.Parse(line.Substring(0, 4));
            int month = int.Parse(line.Substring(5, 2));
            int day = int.Parse(line.Substring(8, 2));
            int hour = int.Parse(line.Substring(11, 2));
            int minute = int.Parse(line.Substring(14, 2));
            double second = double.Parse(line.Substring(17, 10));

            //构建一个日期时间对象，并将秒数初始化为 0 ，然后通过AddSeconds方法再加上给定的秒数（second）。
            DateTime epoch = new DateTime(year, month, day, hour, minute, 0).AddSeconds(second);

            //解析观测值
            string[] fields = line.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);

            //一行至少11个数据
            if (fields.Length < 11)
            {
                return null;
            }

            //构建观测数据对象并返回
            DataModel.SatelliteObservation observation = new DataModel.SatelliteObservation(satelliteID, epoch, double.Parse(fields[5]),
                double.Parse(fields[6]), double.Parse(fields[7]), double.Parse(fields[8]), double.Parse(fields[9]),
                double.Parse(fields[10]), false, double.Parse(fields[5]), double.Parse(fields[6]));


            return observation;
        }

    }
}
