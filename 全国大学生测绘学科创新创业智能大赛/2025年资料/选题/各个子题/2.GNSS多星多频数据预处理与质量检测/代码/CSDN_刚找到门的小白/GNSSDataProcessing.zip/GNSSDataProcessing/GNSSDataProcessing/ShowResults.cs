﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace GNSSDataProcessing
{
    /// <summary>
    /// 在富文本框中展示数据
    /// </summary>
    public class ShowResults
    {
        public (string,string,string) Show(List<DataModel.CycleSlip> cycleSlips, Dictionary<string, double> multipathEstimates, List<DataModel.SatelliteObservation> smoothResults)
        {
            //展示周跳检测结果
            string data1 = "";
            for(int i = 0; i < cycleSlips.Count; i++)
            {
                data1 += cycleSlips[i].ToString();
            }

            //展示多效应检测结果
            string data2 = "";
            foreach (var kvp in multipathEstimates)
            {
                string str1 = kvp.Key.ToString();
                string str2 = kvp.Value.ToString();
                string str = string.Format("{0}\t{1}\n", str1, str2);
                data2 += str;

                str1 = "";
                str2 = "";
                str = "";
            }

            //展示伪距平滑结果
            string data3 = "";
            for(int i = 0; i < smoothResults.Count; i++)
            {
                data3 += smoothResults[i].ToString();
            }

            return (data1, data2, data3);
        }
    }
}
